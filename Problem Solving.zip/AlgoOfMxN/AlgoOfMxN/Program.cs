﻿using System;

namespace AlgoOfMxN
{
    class Solution
    {
        static public void setZeroes(ref int[][] matrix)
        {
            bool[] row = new bool[matrix.Length];
            bool[] column = new bool[matrix[0].Length];

            for (int r = 0; r < matrix.Length; r++)
            {
                for (int c = 0; c < matrix[0].Length; c++)
                {
                    if (matrix[r][c] == 0)
                    {
                        row[r] = true;
                        column[c] = true;
                    }
                }
            }

            for (int i = 0; i < matrix.Length; i++)
            {
                for (int j = 0; j < matrix[0].Length; j++)
                {
                    if (row[i] || column[j])
                    {
                        matrix[i][j] = 0;
                    }
                }
            }

            //Console.WriteLine(matrix);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            /*int[][] matrix = new int[3][]
            {
               new int[] {1,2,3,4,5},
               new int[] { 1, 2, 3, 4, 5 },
               new int[] { 1, 2, 3, 4, 5 }
            };*/

            /*int[][] matrix = new int[3][]
            {
               new int[] {1,2,3,4,5},
               new int[] { 0, 7, 8, 9, 0 },
               new int[] { 0, 2, 4, 6, 8 }
            };*/

            /*int[][] matrix = new int[3][]
            {
               new int[] {1,1,1},
               new int[] {1,0,1},
               new int[] {1, 1, 1}
            };*/

            int[][] matrix = new int[3][]
            {
               new int[] {0,1,2,0},
               new int[] {3,4,5,2},
               new int[] {1,3,1,5}
            };

            Console.WriteLine("Before: ");
            printMatrix(matrix);
            Console.WriteLine("----------------------------------");

            Solution.setZeroes(ref matrix);

            Console.WriteLine("After: ");
            printMatrix(matrix);

            void printMatrix(int[][] matrix)
            {
                foreach (int[] array in matrix)
                {
                    foreach (int item in array)
                    {
                        Console.Write(item + " , ");
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
