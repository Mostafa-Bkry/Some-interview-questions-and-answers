﻿using System;
using System.Collections.Generic;

public class Program
{
	private static void Swap(int[] arr, int i, int j)
	{
		var temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	public static void PeaksAndValleys(int[] arr)
	{
		if (arr == null || arr.Length < 3)
		{
			return;
		}

		for (var i = 1; i < arr.Length - 1; i += 2)
		{
			if (arr[i] > arr[i - 1] && arr[i] > arr[i + 1]) continue;

			var max = Math.Max(Math.Max(arr[i - 1], arr[i]), arr[i + 1]);
			if (arr[i - 1] == max)
			{
				Swap(arr, i, i - 1);
			}
			else Swap(arr, i, i + 1);
		}
	}

	public static void Main()
	{
		var arr = new int[5] { 5, 3, 1, 2, 3 };
		PeaksAndValleys(arr);
		foreach (var e in arr)
		{
			Console.Write(e + " ");
		}
	}
}
