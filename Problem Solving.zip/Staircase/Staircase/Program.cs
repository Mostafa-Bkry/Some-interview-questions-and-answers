﻿using System;

namespace Staircase
{
    class Solution
    {
        static public int findStep(int n)
        {
            if (n == 0)
                return 1;
            else if (n < 0)
                return 0;
            else
                return findStep(n - 3) + findStep(n - 2)
                    + findStep(n - 1);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //int n = 4;
            int n = 3;
            Console.WriteLine(Solution.findStep(n));
        }
    }
}
